import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/note.dart';
import '../providers/note_provider.dart';

class NoteEditorScreen extends StatefulWidget {
  final Note? note;

  const NoteEditorScreen({super.key, this.note});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late TextEditingController _title;
  late TextEditingController _content;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.note?.title ?? "");
    _content = TextEditingController(text: widget.note?.content ?? "");
  }

  void _saveNote() {
    final provider = Provider.of<NoteProvider>(context, listen: false);

    final now = DateTime.now();

    if (widget.note == null) {
      provider.addNote(
        Note(
          title: _title.text,
          content: _content.text,
          createdAt: now,
          updatedAt: now,
        ),
      );
    } else {
      provider.updateNote(
        Note(
          id: widget.note!.id,
          title: _title.text,
          content: _content.text,
          createdAt: widget.note!.createdAt,
          updatedAt: now,
        ),
      );
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? "New Note" : "Edit Note"),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveNote,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _title,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: TextField(
                controller: _content,
                decoration: const InputDecoration(labelText: "Content"),
                maxLines: null,
                expands: true,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
